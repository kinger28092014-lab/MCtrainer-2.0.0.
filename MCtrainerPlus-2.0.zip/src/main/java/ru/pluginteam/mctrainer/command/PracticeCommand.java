package ru.pluginteam.mctrainer.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.gui.PracticeMenu;

public class PracticeCommand implements CommandExecutor {
    private final MCTrainerPlugin plugin;

    public PracticeCommand(MCTrainerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        if (plugin.getSessionManager().isBusy(player.getUniqueId())) {
            player.sendMessage("§cВы уже в тренировке! Напишите /leave чтобы выйти.");
            return true;
        }
        PracticeMenu.open(plugin, player);
        return true;
    }
}
