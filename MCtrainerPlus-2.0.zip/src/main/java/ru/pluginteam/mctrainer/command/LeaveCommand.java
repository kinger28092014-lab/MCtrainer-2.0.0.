package ru.pluginteam.mctrainer.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.pluginteam.mctrainer.MCTrainerPlugin;

public class LeaveCommand implements CommandExecutor {
    private final MCTrainerPlugin plugin;

    public LeaveCommand(MCTrainerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        plugin.getSessionManager().leaveSession(player);
        return true;
    }
}
