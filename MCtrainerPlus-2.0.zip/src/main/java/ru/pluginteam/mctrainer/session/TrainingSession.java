package ru.pluginteam.mctrainer.session;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.arena.ArenaBuilder;
import ru.pluginteam.mctrainer.model.Difficulty;
import ru.pluginteam.mctrainer.model.ProgressLevel;
import ru.pluginteam.mctrainer.model.SessionOptions;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.time.Duration;
import java.util.*;

public class TrainingSession {
    private final MCTrainerPlugin plugin;
    private final Player player;
    private final SessionOptions options;
    private final PlayerSnapshot snapshot;
    private final Location center;
    private final int slotIndex;

    private BukkitTask mainTask;
    private boolean finished = false;
    private int ticksElapsed = 0;
    private int timeLeftSeconds;

    // Общая статистика для всех режимов
    private int hits = 0;
    private int misses = 0;
    private int currentStreak = 0;
    private int bestStreak = 0;

    // Tracking
    private ArmorStand trackingStand;
    private double trackingAngle = 0.0;
    private int trackingOnTargetTicks = 0;
    private int trackingTotalTicks = 0;

    // Flick (блоки + BlockDisplay с красной обводкой)
    private final Map<Location, BlockDisplay> flickTargets = new HashMap<>();

    // Clutch
    private int clutchDropsDone = 0;
    private int clutchSuccesses = 0;
    private int clutchHeight;
    private boolean clutchFalling = false;
    private Location placedWaterLoc = null;

    // StunSlam
    private Zombie stunNpc;
    private boolean npcShieldUp = true;
    private boolean shieldBrokenThisJump = false;
    private boolean slamCompletedThisJump = false;
    private boolean inJump = false;

    // Pearl Aim
    private Zombie pearlNpc;

    // Anchor Trainer
    private boolean anchorTimerStarted = false;
    private int anchorsExploded = 0;

    // Bot trainers (Mace, Crystal, Sword)
    private Zombie botNpc;
    private int botStrafeDir = 1;
    private int botStrafeTimer = 0;

    private final Random random = new Random();

    public TrainingSession(MCTrainerPlugin plugin, Player player, SessionOptions options, Location center, int slotIndex) {
        this.plugin = plugin;
        this.player = player;
        this.options = options;
        this.snapshot = new PlayerSnapshot(player);
        this.center = center;
        this.slotIndex = slotIndex;

        if (options.getProgressLevel() > 0) {
            options.setDifficulty(ProgressLevel.getDifficultyForLevel(options.getProgressLevel()));
            options.setInfinite(false);
            if (options.getType() == TrainerType.CLUTCH) {
                options.setClutchHeight(ProgressLevel.getClutchHeightForLevel(options.getProgressLevel()));
            }
        }

        this.clutchHeight = options.getClutchHeight();
        this.timeLeftSeconds = options.getType() == TrainerType.ANCHOR ? 15 : 60;
    }

    public void start() {
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.getInventory().setItemInOffHand(null);
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.setFallDistance(0f);
        player.setFireTicks(0);
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));

        switch (options.getType()) {
            case TRACKING -> setupTracking();
            case FLICK -> setupFlick();
            case CLUTCH -> setupClutch();
            case STUNSLAM -> setupStunSlam();
            case PEARL_AIM -> setupPearlAim();
            case ANCHOR -> setupAnchor();
            case MACE, CRYSTAL, SWORD -> setupBotTrainer();
        }

        if (options.getProgressLevel() > 0) {
            player.sendMessage("§6[Прогресс] §eУровень " + options.getProgressLevel() +
                    " §7— Цель: §a" + ProgressLevel.getGoalDescription(options.getType(), options.getProgressLevel()));
        }

        mainTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (finished || !player.isOnline()) {
                    cancel();
                    return;
                }
                tick();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void setupTracking() {
        ArenaBuilder.buildBoxArena(center, 11, 16, Material.SMOOTH_STONE, Material.BLACK_STAINED_GLASS, true);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(center.clone().add(0.5, 0.5, 0.5));

        trackingStand = center.getWorld().spawn(center.clone().add(0.5, 1.5, 4.5), ArmorStand.class, stand -> {
            stand.setGravity(false);
            stand.setMarker(true); // Проходит сквозь игрока без коллизий!
            stand.setInvulnerable(true);
            stand.setArms(true);
            stand.setBasePlate(false);
            stand.getEquipment().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
            stand.getEquipment().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
            stand.getEquipment().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
            stand.getEquipment().setBoots(new ItemStack(Material.DIAMOND_BOOTS));
            stand.customName(Component.text("§bЦель"));
            stand.setCustomNameVisible(true);
        });
        player.sendMessage("§b[Tracking] §7Удерживайте прицел на стойке! Скорость: " + options.getDifficulty().getDisplayName());
    }

    private void setupFlick() {
        ArenaBuilder.buildBoxArena(center, 10, 14, Material.SMOOTH_STONE, Material.GRAY_CONCRETE, true);
        player.setGameMode(GameMode.ADVENTURE);
        Location spawn = center.clone().add(0.5, 0.5, 4.5);
        spawn.setYaw(180f);
        spawn.setPitch(0f);
        player.teleport(spawn);
        player.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));

        for (int i = 0; i < 3; i++) {
            spawnFlickTarget();
        }
        player.sendMessage("§e[Flick] §7Нажимайте ЛКМ по подсвеченным блокам с красной границей!");
    }

    private void spawnFlickTarget() {
        World w = center.getWorld();
        for (int attempt = 0; attempt < 30; attempt++) {
            int dx = random.nextInt(11) - 5; // -5..5
            int dy = random.nextInt(6) + 1;  // 1..6
            Location loc = new Location(w, center.getBlockX() + dx, center.getBlockY() + dy, center.getBlockZ() - 5);
            if (!flickTargets.containsKey(loc)) {
                // Приятный цвет блока (Вишнёвые доски) + яркая красная обводка через BlockDisplay
                loc.getBlock().setType(Material.CHERRY_PLANKS, false);
                BlockDisplay display = w.spawn(loc, BlockDisplay.class, d -> {
                    d.setBlock(Material.CHERRY_PLANKS.createBlockData());
                    d.setGlowing(true);
                    d.setGlowColorOverride(Color.RED);
                });
                flickTargets.put(loc, display);
                return;
            }
        }
    }

    private void setupClutch() {
        ArenaBuilder.buildClutchArena(center, clutchHeight);
        player.setGameMode(GameMode.SURVIVAL);
        resetClutchDrop();
        player.sendMessage("§3[Clutch] §7Высота: §e" + clutchHeight + " бл. §7Выполните §a5 §7успешных ватердропов из §e6 §7падений!");
    }

    public void resetClutchDrop() {
        if (placedWaterLoc != null) {
            placedWaterLoc.getBlock().setType(Material.AIR, false);
            placedWaterLoc = null;
        }
        player.getInventory().clear();
        player.getInventory().setItem(0, new ItemStack(Material.WATER_BUCKET));
        player.setHealth(20.0);
        player.setFallDistance(0f);
        player.setVelocity(new Vector(0, 0, 0));
        Location top = center.clone().add(0.5, clutchHeight, 0.5);
        player.teleport(top);
        clutchFalling = false;
    }

    private void setupStunSlam() {
        ArenaBuilder.buildBoxArena(center, 10, 22, Material.SMOOTH_STONE, Material.DEEPSLATE_BRICKS, true);
        player.setGameMode(GameMode.SURVIVAL);
        Location pSpawn = center.clone().add(0.5, 0.5, 4.5);
        pSpawn.setYaw(180f);
        player.teleport(pSpawn);

        player.getInventory().setItem(0, new ItemStack(Material.NETHERITE_AXE));
        player.getInventory().setItem(1, new ItemStack(Material.MACE));

        Location npcLoc = center.clone().add(0.5, 0.5, -1.5);
        stunNpc = spawnStaticNpc(npcLoc, "§6NPC со щитом", true);
        npcShieldUp = true;

        player.sendMessage("§6[StunSlam] §7Прыгните (усиленный прыжок ветра), сбейте щит §eтопором §7и ударьте §dбулавой §7в 1 прыжке!");
    }

    private void setupPearlAim() {
        ArenaBuilder.buildBoxArena(center, 22, 18, Material.SMOOTH_STONE, Material.PURPLE_STAINED_GLASS, true);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(center.clone().add(0.5, 0.5, 0.5));
        giveInfinitePearls();

        pearlNpc = spawnStaticNpc(getRandomPearlLocation(), "§5Цель (Pearl Aim)", false);
        player.sendMessage("§5[Pearl Aim] §7Попадайте эндер-жемчугом в NPC! Сложность: " + options.getDifficulty().getDisplayName());
    }

    private void giveInfinitePearls() {
        ItemStack pearls = new ItemStack(Material.ENDER_PEARL, 16);
        ItemMeta meta = pearls.getItemMeta();
        meta.displayName(Component.text("§5Бесконечный жемчуг"));
        pearls.setItemMeta(meta);
        player.getInventory().setItem(0, pearls);
    }

    private Location getRandomPearlLocation() {
        int minD = options.getDifficulty().getPearlMinDist();
        int maxD = Math.min(20, options.getDifficulty().getPearlMaxDist());
        if (minD >= maxD) minD = Math.max(4, maxD - 4);

        Location pLoc = player.getLocation();
        for (int i = 0; i < 30; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = minD + random.nextDouble() * (maxD - minD);
            double x = pLoc.getX() + Math.cos(angle) * dist;
            double z = pLoc.getZ() + Math.sin(angle) * dist;
            // Держим внутри арены (радиус 20)
            x = Math.max(center.getBlockX() - 19, Math.min(center.getBlockX() + 19, x));
            z = Math.max(center.getBlockZ() - 19, Math.min(center.getBlockZ() + 19, z));
            return new Location(center.getWorld(), Math.floor(x) + 0.5, center.getBlockY(), Math.floor(z) + 0.5);
        }
        return center.clone().add(8.5, 0.5, 0.5);
    }

    private void setupAnchor() {
        ArenaBuilder.buildAnchorArena(center);
        player.setGameMode(GameMode.SURVIVAL);
        player.teleport(center.clone().add(0.5, 0.5, 0.5));
        player.getInventory().setItem(0, new ItemStack(Material.RESPAWN_ANCHOR, 64));
        player.getInventory().setItem(1, new ItemStack(Material.GLOWSTONE, 64));
        player.getInventory().setItem(2, new ItemStack(Material.OBSIDIAN, 64));
        player.sendMessage("§c[Anchor Trainer] §7Поставьте первый якорь возрождения — запустится таймер §e15 секунд§7!");
    }

    private void setupBotTrainer() {
        ArenaBuilder.buildBoxArena(center, 12, 22, Material.SMOOTH_STONE, Material.STONE_BRICKS, true);
        player.setGameMode(GameMode.SURVIVAL);
        player.teleport(center.clone().add(0.5, 0.5, 5.5));

        if (options.getType() == TrainerType.MACE) {
            player.getInventory().setItem(0, new ItemStack(Material.MACE));
            player.getInventory().setItem(1, new ItemStack(Material.WIND_CHARGE, 64));
        } else if (options.getType() == TrainerType.CRYSTAL) {
            player.getInventory().setItem(0, new ItemStack(Material.OBSIDIAN, 64));
            player.getInventory().setItem(1, new ItemStack(Material.END_CRYSTAL, 64));
            player.getInventory().setItem(2, new ItemStack(Material.RESPAWN_ANCHOR, 64));
            player.getInventory().setItem(3, new ItemStack(Material.GLOWSTONE, 64));
        } else {
            player.getInventory().setItem(0, new ItemStack(Material.DIAMOND_SWORD));
        }

        botNpc = spawnStaticNpc(center.clone().add(0.5, 0.5, -3.5), "§bТренировочный бот", false);
        player.sendMessage(options.getType().getDisplayName() + " §7— Отрабатывайте удары по боту!");
    }

    private Zombie spawnStaticNpc(Location loc, String name, boolean withShield) {
        return loc.getWorld().spawn(loc, Zombie.class, z -> {
            z.setAdult();
            z.setShouldBurnInDay(false);
            z.setAI(false);
            z.setSilent(true);
            z.setGravity(true);
            z.setRemoveWhenFarAway(false);
            z.customName(Component.text(name));
            z.setCustomNameVisible(true);

            AttributeInstance kb = z.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
            if (kb != null) kb.setBaseValue(1.0);
            AttributeInstance mh = z.getAttribute(Attribute.MAX_HEALTH);
            if (mh != null) {
                mh.setBaseValue(1000.0);
                z.setHealth(1000.0);
            }

            z.getEquipment().setHelmet(new ItemStack(Material.IRON_HELMET));
            z.getEquipment().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
            z.getEquipment().setLeggings(new ItemStack(Material.IRON_LEGGINGS));
            z.getEquipment().setBoots(new ItemStack(Material.IRON_BOOTS));
            if (withShield) {
                z.getEquipment().setItemInOffHand(new ItemStack(Material.SHIELD));
            }
        });
    }

    private void tick() {
        ticksElapsed++;

        // Обновление таймера (раз в секунду)
        if (ticksElapsed % 20 == 0) {
            boolean shouldCountDown = !options.isInfinite()
                    && options.getType() != TrainerType.CLUTCH
                    && (options.getType() != TrainerType.ANCHOR || anchorTimerStarted);
            if (shouldCountDown) {
                timeLeftSeconds--;
                if (timeLeftSeconds <= 0) {
                    finish(false);
                    return;
                }
            }
        }

        switch (options.getType()) {
            case TRACKING -> tickTracking();
            case FLICK -> tickFlickActionBar();
            case CLUTCH -> tickClutch();
            case STUNSLAM -> tickStunSlam();
            case PEARL_AIM -> tickPearlAim();
            case ANCHOR -> tickAnchor();
            case MACE, CRYSTAL, SWORD -> tickBotTrainer();
        }
    }

    private void tickTracking() {
        if (trackingStand == null || trackingStand.isDead()) return;
        Difficulty diff = options.getDifficulty();
        trackingAngle += diff.getTrackingSpeed();

        // Траектория восьмёрки (Лиссажу), проходящая прямо через центр / игрока!
        double x = Math.sin(trackingAngle) * 5.5;
        double z = Math.sin(trackingAngle * 2.0) * 4.0;
        double y = 1.5 + Math.sin(trackingAngle * 1.3 * (diff.getTrackingVertical() / 0.04 + 0.5)) * 2.2;

        Location next = center.clone().add(0.5 + x, Math.max(0.5, y), 0.5 + z);
        trackingStand.teleport(next);

        // Проверка прицела игрока на стойку
        trackingTotalTicks++;
        Vector eye = player.getEyeLocation().toVector();
        Vector dir = player.getEyeLocation().getDirection().normalize();
        Vector targetCenter = trackingStand.getLocation().toVector().add(new Vector(0, 1.0, 0));
        Vector toTarget = targetCenter.clone().subtract(eye);
        double dist = toTarget.length();
        double dot = toTarget.normalize().dot(dir);
        double perpDist = dist * Math.sqrt(Math.max(0, 1.0 - dot * dot));

        if (dot > 0 && perpDist < 0.85) {
            trackingOnTargetTicks++;
            if (trackingOnTargetTicks % 4 == 0) {
                hits++;
                currentStreak++;
                if (currentStreak > bestStreak) bestStreak = currentStreak;
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.3f, 1.8f);
            }
        } else {
            if (trackingTotalTicks % 10 == 0) {
                misses++;
                currentStreak = 0;
            }
        }

        int pct = trackingTotalTicks > 0 ? (int) ((trackingOnTargetTicks * 100.0) / trackingTotalTicks) : 0;
        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§bТочность: §a" + pct + "% §7| §eОчки: §f" + hits + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    private void tickFlickActionBar() {
        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§aПопадания: §f" + hits + " §7| §cПромахи: §f" + misses + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    private void tickClutch() {
        if (player.getLocation().getY() < center.getBlockY() + clutchHeight - 2.0) {
            clutchFalling = true;
        }
        // Если игрок приземлился в воду на полу арены
        if (clutchFalling && player.getLocation().getY() <= center.getBlockY() + 1.2) {
            Material feet = player.getLocation().getBlock().getType();
            Material below = player.getLocation().clone().subtract(0, 0.3, 0).getBlock().getType();
            if (feet == Material.WATER || below == Material.WATER) {
                handleClutchResult(true);
            } else if (player.isOnGround() && player.getFallDistance() == 0f) {
                // Подстраховка, если урон не прошёл, но воды нет
                handleClutchResult(false);
            }
        }
        player.sendActionBar(Component.text("§3Падение: §e" + (clutchDropsDone + 1) + "/6 §7| §aУспешно: §f" + clutchSuccesses + "/5 §7| §6Серия: §f" + currentStreak + " §7| §7Высота: §b" + clutchHeight));
    }

    public void handleClutchResult(boolean success) {
        if (!clutchFalling || finished) return;
        clutchFalling = false;
        clutchDropsDone++;

        if (success) {
            clutchSuccesses++;
            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
            player.sendMessage("§a✔ Клатч выполнен! (" + clutchSuccesses + "/5)");
        } else {
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            player.sendMessage("§c✘ Промах!");
        }

        // Если выполнено 5 клатчей подряд — повышаем рекомендуемую высоту на +5
        if (currentStreak >= 5) {
            int currentRec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());
            int newRec = Math.max(currentRec, clutchHeight + 5);
            if (newRec > currentRec) {
                plugin.getDataStore().setRecommendedClutchHeight(player.getUniqueId(), newRec);
                player.sendMessage("§b★ 5 клатчей подряд! Новая рекомендуемая высота: §e" + newRec + " блоков!");
            }
        }

        if (clutchSuccesses >= 5 || clutchDropsDone >= 6) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> finish(false), 15L);
        } else {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!finished) resetClutchDrop();
            }, 15L);
        }
    }

    public void setPlacedWaterLoc(Location loc) {
        this.placedWaterLoc = loc;
    }

    private void tickStunSlam() {
        if (stunNpc != null && !stunNpc.isDead()) {
            // NPC всегда смотрит на игрока
            Location npcLoc = stunNpc.getLocation();
            Vector dir = player.getLocation().toVector().subtract(npcLoc.toVector());
            npcLoc.setDirection(dir);
            stunNpc.teleport(npcLoc);
        }

        if (inJump && player.isOnGround() && player.getVelocity().getY() <= 0) {
            inJump = false;
            if (!slamCompletedThisJump && shieldBrokenThisJump) {
                misses++;
                currentStreak = 0;
            }
            shieldBrokenThisJump = false;
            slamCompletedThisJump = false;
        }

        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§6Серия StunSlam: §e" + currentStreak + " §7| §aУдары: §f" + hits + " §7| §bМакс. серия: §f" + bestStreak + " §7| §7Время: §f" + timeStr));
    }

    public void handleStunSlamJump() {
        if (finished || options.getType() != TrainerType.STUNSLAM) return;
        // Сила прыжка как от заряда ветра
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!finished && player.isOnline()) {
                Vector vel = player.getVelocity();
                vel.setY(1.22);
                player.setVelocity(vel);
                player.playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 0.8f, 1.1f);
                inJump = true;
                shieldBrokenThisJump = false;
                slamCompletedThisJump = false;
            }
        });
    }

    public void handleStunSlamHit(Entity target) {
        if (finished || stunNpc == null || !target.getUniqueId().equals(stunNpc.getUniqueId())) return;
        Material hand = player.getInventory().getItemInMainHand().getType();

        // 1. Сбитие щита топором
        if (hand.name().endsWith("_AXE") && npcShieldUp) {
            npcShieldUp = false;
            shieldBrokenThisJump = true;
            stunNpc.getEquipment().setItemInOffHand(null);
            player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BREAK, 1f, 1f);

            // Щит возвращается через 0.5 секунды (10 тиков)
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!finished && stunNpc != null && !stunNpc.isDead()) {
                    npcShieldUp = true;
                    stunNpc.getEquipment().setItemInOffHand(new ItemStack(Material.SHIELD));
                }
            }, 10L);
            return;
        }

        // 2. Удар булавой в том же прыжке после сбития щита
        if (hand == Material.MACE && shieldBrokenThisJump && !slamCompletedThisJump && inJump) {
            slamCompletedThisJump = true;
            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.ITEM_MACE_SMASH_GROUND, 1f, 1.1f);
            player.showTitle(Title.title(
                    Component.text("§6§lStunslame!"),
                    Component.text("§eСерия: " + currentStreak),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(700), Duration.ofMillis(200))
            ));
        } else if (hand == Material.MACE && npcShieldUp) {
            // Удар булавой в зажатый щит — промах
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1f);
        }
    }

    private void tickPearlAim() {
        if (pearlNpc != null && !pearlNpc.isDead()) {
            Location loc = pearlNpc.getLocation();
            loc.setDirection(player.getLocation().toVector().subtract(loc.toVector()));
            pearlNpc.teleport(loc);
        }
        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§aПопадания: §f" + hits + " §7| §cПромахи: §f" + misses + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    public void handlePearlImpact(Location impactLoc, Entity hitEntity) {
        if (finished || options.getType() != TrainerType.PEARL_AIM || pearlNpc == null) return;
        giveInfinitePearls();

        boolean hit = (hitEntity != null && hitEntity.getUniqueId().equals(pearlNpc.getUniqueId()))
                || (impactLoc.getWorld().equals(pearlNpc.getWorld())
                && impactLoc.distance(pearlNpc.getLocation().clone().add(0, 1.0, 0)) <= 1.65);

        if (hit) {
            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.5f);
            pearlNpc.teleport(getRandomPearlLocation());
        } else {
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1.2f);
        }
    }

    private void tickAnchor() {
        String status = anchorTimerStarted ? ("§cОсталось: §e" + timeLeftSeconds + "с") : "§7Поставьте первый якорь...";
        player.sendActionBar(Component.text("§cВзорвано якорей: §e" + anchorsExploded + " §7| " + status));
    }

    public void handleAnchorPlaced() {
        if (!anchorTimerStarted) {
            anchorTimerStarted = true;
            player.sendMessage("§c[Anchor Trainer] §eТаймер 15 секунд пошёл! Взрывайте якоря!");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
        }
    }

    public void handleAnchorExploded() {
        anchorsExploded++;
        hits++;
        currentStreak++;
        if (currentStreak > bestStreak) bestStreak = currentStreak;
        // Восполняем якоря и светокамень
        if (!player.getInventory().contains(Material.RESPAWN_ANCHOR, 16)) {
            player.getInventory().addItem(new ItemStack(Material.RESPAWN_ANCHOR, 32));
        }
        if (!player.getInventory().contains(Material.GLOWSTONE, 16)) {
            player.getInventory().addItem(new ItemStack(Material.GLOWSTONE, 32));
        }
    }

    private void tickBotTrainer() {
        if (botNpc == null || botNpc.isDead()) return;
        botStrafeTimer++;
        if (botStrafeTimer > 25) {
            botStrafeTimer = 0;
            if (random.nextBoolean()) botStrafeDir = -botStrafeDir;
        }

        double speed = options.getDifficulty().getBotSpeed();
        Location bLoc = botNpc.getLocation();
        Vector toPlayer = player.getLocation().toVector().subtract(bLoc.toVector()).setY(0);
        if (toPlayer.lengthSquared() > 0.01) {
            toPlayer.normalize();
            Vector strafe = new Vector(-toPlayer.getZ(), 0, toPlayer.getX()).multiply(botStrafeDir * speed);
            Location next = bLoc.clone().add(strafe);
            if (Math.abs(next.getX() - center.getX()) < 10 && Math.abs(next.getZ() - center.getZ()) < 10) {
                next.setDirection(toPlayer);
                botNpc.teleport(next);
            } else {
                botStrafeDir = -botStrafeDir;
            }
        }
        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§aУдары: §f" + hits + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    public void handleBotHit(Entity target) {
        if (finished || botNpc == null || !target.getUniqueId().equals(botNpc.getUniqueId())) return;
        hits++;
        currentStreak++;
        if (currentStreak > bestStreak) bestStreak = currentStreak;
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.4f);
    }

    public void handleFlickClick() {
        if (finished || options.getType() != TrainerType.FLICK) return;
        // Рейтрейс по блокам мишеней без частиц удара
        Block hitBlock = player.getTargetBlockExact(20);
        if (hitBlock != null && flickTargets.containsKey(hitBlock.getLocation())) {
            Location loc = hitBlock.getLocation();
            BlockDisplay disp = flickTargets.remove(loc);
            if (disp != null) disp.remove();
            loc.getBlock().setType(Material.AIR, false);

            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.8f);
            spawnFlickTarget();
        } else {
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.4f, 1.2f);
        }
    }

    public void finish(boolean silent) {
        if (finished) return;
        finished = true;
        if (mainTask != null) mainTask.cancel();

        // Уборка сущностей
        if (trackingStand != null) trackingStand.remove();
        if (stunNpc != null) stunNpc.remove();
        if (pearlNpc != null) pearlNpc.remove();
        if (botNpc != null) botNpc.remove();
        for (BlockDisplay d : flickTargets.values()) d.remove();
        flickTargets.clear();

        // Очистка / восстановление арены после окончания тренировки
        if (options.getType() == TrainerType.CLUTCH) {
            ArenaBuilder.clearArea(center, 9, 9, -2, clutchHeight + 9);
        } else if (options.getType() == TrainerType.PEARL_AIM) {
            ArenaBuilder.clearArea(center, 23, 23, -2, 19);
        } else if (options.getType() == TrainerType.ANCHOR) {
            ArenaBuilder.clearArea(center, 11, 11, -3, 15);
        } else {
            ArenaBuilder.clearArea(center, 13, 13, -2, 23);
        }

        if (player.isOnline()) {
            snapshot.restore(player);
            if (!silent) {
                sendSummary();
            }
        }

        plugin.getSessionManager().removeSoloSession(player.getUniqueId(), slotIndex);
    }

    private void sendSummary() {
        player.sendMessage("§8§m----------------------------------------");
        player.sendMessage("§6§lРезультаты тренировки: " + options.getType().getDisplayName());
        player.sendMessage("§aПопадания / Успехи: §f" + hits);
        player.sendMessage("§cПромахи: §f" + misses);
        player.sendMessage("§eЛучшая серия: §f" + bestStreak);

        if (options.getType() == TrainerType.ANCHOR) {
            player.sendMessage("§cВзорвано якорей: §f" + anchorsExploded);
        } else if (options.getType() == TrainerType.CLUTCH) {
            int rec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());
            player.sendMessage("§3Клатчей выполнено: §f" + clutchSuccesses + "/5 §7(Рекомендуемая высота: §b" + rec + " бл.§7)");
        }

        // Проверка прохождения уровня в режиме Прогресс
        if (options.getProgressLevel() > 0) {
            int lvl = options.getProgressLevel();
            int goal = ProgressLevel.getGoalForLevel(options.getType(), lvl);
            int score = options.getType() == TrainerType.CLUTCH ? clutchSuccesses
                    : (options.getType() == TrainerType.ANCHOR ? anchorsExploded : hits);

            if (score >= goal) {
                plugin.getDataStore().unlockNextLevel(player.getUniqueId(), options.getType(), lvl);
                player.sendMessage("§a§l✔ УРОВЕНЬ " + lvl + " ПРОЙДЕН! §7Открыт следующий уровень в режиме «Прогресс»!");
                player.showTitle(Title.title(
                        Component.text("§a§lУровень " + lvl + " пройден!"),
                        Component.text("§eСледующий уровень открыт!"),
                        Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))
                ));
            } else {
                player.sendMessage("§c✘ Уровень " + lvl + " не пройден (§f" + score + "/" + goal + "§c). Попробуйте ещё раз!");
            }
        }
        player.sendMessage("§8§m----------------------------------------");
    }

    public TrainerType getType() { return options.getType(); }
    public boolean isFinished() { return finished; }
    public Location getCenter() { return center; }
    public Zombie getStunNpc() { return stunNpc; }
    public Zombie getBotNpc() { return botNpc; }
}
