package ru.pluginteam.mctrainer;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import ru.pluginteam.mctrainer.command.DuelTrainerCommand;
import ru.pluginteam.mctrainer.command.LeaveCommand;
import ru.pluginteam.mctrainer.command.PracticeCommand;
import ru.pluginteam.mctrainer.listener.TrainingListener;
import ru.pluginteam.mctrainer.model.TrainerType;
import ru.pluginteam.mctrainer.session.SessionManager;
import ru.pluginteam.mctrainer.storage.PlayerDataStore;

public class MCTrainerPlugin extends JavaPlugin {

    private PlayerDataStore dataStore;
    private SessionManager sessionManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.dataStore = new PlayerDataStore(this);
        this.sessionManager = new SessionManager(this);

        getCommand("practice").setExecutor(new PracticeCommand(this));
        getCommand("leave").setExecutor(new LeaveCommand(this));
        getCommand("tracking").setExecutor(new DuelTrainerCommand(this, TrainerType.TRACKING));
        getCommand("flick").setExecutor(new DuelTrainerCommand(this, TrainerType.FLICK));

        Bukkit.getPluginManager().registerEvents(new TrainingListener(this), this);

        getLogger().info("MCtrainerPlus 2.0.0 успешно запущен!");
    }

    @Override
    public void onDisable() {
        if (sessionManager != null) {
            sessionManager.shutdownAll();
        }
        if (dataStore != null) {
            dataStore.save();
        }
    }

    public PlayerDataStore getDataStore() {
        return dataStore;
    }

    public SessionManager getSessionManager() {
        return sessionManager;
    }
}
