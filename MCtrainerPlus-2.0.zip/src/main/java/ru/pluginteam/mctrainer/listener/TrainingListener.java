package ru.pluginteam.mctrainer.listener;

import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.gui.PracticeMenu;
import ru.pluginteam.mctrainer.gui.ProgressMenu;
import ru.pluginteam.mctrainer.gui.StartConfigMenu;
import ru.pluginteam.mctrainer.model.SessionOptions;
import ru.pluginteam.mctrainer.model.TrainerType;
import ru.pluginteam.mctrainer.session.DuelSession;
import ru.pluginteam.mctrainer.session.TrainingSession;

public class TrainingListener implements Listener {
    private final MCTrainerPlugin plugin;

    public TrainingListener(MCTrainerPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = PlainTextComponentSerializer.plainText().serialize(e.getView().title());

        // 1. Главное меню /practice
        if (title.equals(PracticeMenu.TITLE)) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            NamespacedKey key = new NamespacedKey(plugin, "trainer_type");
            String typeName = clicked.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
            if (typeName == null) return;
            TrainerType type = TrainerType.valueOf(typeName);
            SessionOptions opt = plugin.getSessionManager().getOrCreateOptions(player.getUniqueId(), type);
            opt.setProgressLevel(0);
            StartConfigMenu.open(plugin, player, opt);
            return;
        }

        // 2. Меню настройки тренировки
        if (title.equals(StartConfigMenu.TITLE)) {
            e.setCancelled(true);
            SessionOptions opt = plugin.getSessionManager().getPendingOptions(player.getUniqueId());
            if (opt == null) return;

            if (e.getSlot() == 22) {
                PracticeMenu.open(plugin, player);
                return;
            }
            if (e.getSlot() == 14) {
                ProgressMenu.open(plugin, player, opt.getType());
                return;
            }
            if (e.getSlot() == 16) {
                opt.setProgressLevel(0);
                player.closeInventory();
                plugin.getSessionManager().startSoloSession(player, opt);
                return;
            }

            if (opt.getType() == TrainerType.CLUTCH) {
                if (e.getSlot() == 10) {
                    opt.setClutchHeight(opt.getClutchHeight() - 5);
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 11) {
                    int rec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());
                    opt.setClutchHeight(rec);
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 12) {
                    opt.setClutchHeight(opt.getClutchHeight() + 5);
                    StartConfigMenu.open(plugin, player, opt);
                }
            } else {
                if (e.getSlot() == 10 && opt.getType() != TrainerType.ANCHOR) {
                    opt.setDifficulty(opt.getDifficulty().next());
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 12 && opt.getType() != TrainerType.ANCHOR) {
                    opt.setInfinite(!opt.isInfinite());
                    StartConfigMenu.open(plugin, player, opt);
                }
            }
            return;
        }

        // 3. Меню уровней «Прогресс»
        if (title.equals(ProgressMenu.TITLE)) {
            e.setCancelled(true);
            SessionOptions opt = plugin.getSessionManager().getPendingOptions(player.getUniqueId());
            if (opt == null) return;

            if (e.getSlot() == 22) {
                StartConfigMenu.open(plugin, player, opt);
                return;
            }

            int lvl = e.getSlot() - 10; // слоты 11..15 -> уровни 1..5
            if (lvl >= 1 && lvl <= 5) {
                int unlocked = plugin.getDataStore().getUnlockedLevel(player.getUniqueId(), opt.getType());
                if (lvl > unlocked) {
                    player.sendMessage("§cСначала пройдите уровень " + unlocked + "!");
                    return;
                }
                opt.setProgressLevel(lvl);
                player.closeInventory();
                plugin.getSessionManager().startSoloSession(player, opt);
            }
        }
    }

    @EventHandler
    public void onJump(PlayerJumpEvent e) {
        TrainingSession session = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
        if (session != null && session.getType() == TrainerType.STUNSLAM) {
            session.handleStunSlamJump();
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
        DuelSession duel = plugin.getSessionManager().getDuelSession(p.getUniqueId());

        // Flick: ЛКМ по блоку без частиц удара
        if (e.getAction() == Action.LEFT_CLICK_AIR || e.getAction() == Action.LEFT_CLICK_BLOCK) {
            if (solo != null && solo.getType() == TrainerType.FLICK) {
                e.setCancelled(true);
                solo.handleFlickClick();
                return;
            }
            if (duel != null && duel.getType() == TrainerType.FLICK) {
                e.setCancelled(true);
                duel.handleFlickClick(p);
                return;
            }
        }

        // Anchor Trainer: подсчёт взрыва заряженного якоря
        if (solo != null && solo.getType() == TrainerType.ANCHOR && e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Block b = e.getClickedBlock();
            if (b != null && b.getType() == Material.RESPAWN_ANCHOR) {
                if (b.getBlockData() instanceof RespawnAnchor anchor) {
                    ItemStack hand = e.getItem();
                    boolean holdingGlowstone = hand != null && hand.getType() == Material.GLOWSTONE;
                    if (anchor.getCharges() > 0 && (!holdingGlowstone || anchor.getCharges() >= anchor.getMaximumCharges())) {
                        solo.handleAnchorExploded();
                    }
                }
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent e) {
        if (plugin.getSessionManager().isBusy(e.getPlayer().getUniqueId())) {
            TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
            if (solo == null || solo.getType() != TrainerType.ANCHOR) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent e) {
        TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
        if (solo != null && solo.getType() == TrainerType.ANCHOR && e.getBlockPlaced().getType() == Material.RESPAWN_ANCHOR) {
            solo.handleAnchorPlaced();
        }
    }

    @EventHandler
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
        if (solo != null && solo.getType() == TrainerType.CLUTCH && e.getBucket() == Material.WATER_BUCKET) {
            solo.setPlacedWaterLoc(e.getBlock().getLocation());
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
            DuelSession duel = plugin.getSessionManager().getDuelSession(p.getUniqueId());

            if (solo != null) {
                if (solo.getType() == TrainerType.CLUTCH && e.getCause() == EntityDamageEvent.DamageCause.FALL) {
                    e.setCancelled(true);
                    solo.handleClutchResult(false);
                } else {
                    e.setCancelled(true);
                }
            } else if (duel != null) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onDamageByEntity(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
        if (solo == null) return;

        if (solo.getType() == TrainerType.STUNSLAM) {
            e.setDamage(0.0);
            solo.handleStunSlamHit(e.getEntity());
        } else if (solo.getType() == TrainerType.MACE || solo.getType() == TrainerType.CRYSTAL || solo.getType() == TrainerType.SWORD) {
            e.setDamage(0.0);
            solo.handleBotHit(e.getEntity());
        }
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent e) {
        if (!(e.getEntity() instanceof EnderPearl pearl)) return;
        if (!(pearl.getShooter() instanceof Player p)) return;
        TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
        if (solo != null && solo.getType() == TrainerType.PEARL_AIM) {
            solo.handlePearlImpact(pearl.getLocation(), e.getHitEntity());
            pearl.remove();
        }
    }

    @EventHandler
    public void onPearlTeleport(PlayerTeleportEvent e) {
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
            if (solo != null && solo.getType() == TrainerType.PEARL_AIM) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (plugin.getSessionManager().isBusy(e.getPlayer().getUniqueId())) {
            plugin.getSessionManager().leaveSession(e.getPlayer());
        }
    }
}
