package ru.pluginteam.mctrainer.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.model.SessionOptions;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.util.List;

public class StartConfigMenu {
    public static final String TITLE = "§8Настройка тренировки";

    public static void open(MCTrainerPlugin plugin, Player player, SessionOptions opt) {
        Inventory inv = Bukkit.createInventory(null, 27, Component.text(TITLE));

        // Слот 10: Сложность (для Tracking, Pearl Aim, Bot)
        if (opt.getType() != TrainerType.CLUTCH && opt.getType() != TrainerType.ANCHOR) {
            ItemStack diff = new ItemStack(Material.CLOCK);
            ItemMeta dm = diff.getItemMeta();
            dm.displayName(Component.text("§eСложность: " + opt.getDifficulty().getDisplayName()));
            dm.lore(List.of(Component.text("§7Нажмите, чтобы переключить скорость / дистанцию.")));
            diff.setItemMeta(dm);
            inv.setItem(10, diff);
        }

        // Для Clutch: настройка высоты (-5, +5, и Рекомендуемая высота)
        if (opt.getType() == TrainerType.CLUTCH) {
            int rec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());

            ItemStack minus = new ItemStack(Material.RED_WOOL);
            ItemMeta mm = minus.getItemMeta();
            mm.displayName(Component.text("§c-5 блоков высоты"));
            minus.setItemMeta(mm);
            inv.setItem(10, minus);

            ItemStack heightInfo = new ItemStack(Material.WATER_BUCKET);
            ItemMeta hm = heightInfo.getItemMeta();
            hm.displayName(Component.text("§bВысота падения: §e" + opt.getClutchHeight() + " бл."));
            hm.lore(List.of(
                    Component.text("§7Рекомендуемая высота: §a" + rec + " бл."),
                    Component.text("§eНажмите, чтобы выбрать рекомендуемую!")
            ));
            heightInfo.setItemMeta(hm);
            inv.setItem(11, heightInfo);

            ItemStack plus = new ItemStack(Material.LIME_WOOL);
            ItemMeta pm = plus.getItemMeta();
            pm.displayName(Component.text("§a+5 блоков высоты"));
            plus.setItemMeta(pm);
            inv.setItem(12, plus);
        }

        // Слот 12: Бесконечный режим (для StunSlam, Pearl Aim, Tracking, Flick, Bot)
        if (opt.getType() != TrainerType.CLUTCH && opt.getType() != TrainerType.ANCHOR) {
            ItemStack inf = new ItemStack(opt.isInfinite() ? Material.NETHER_STAR : Material.SAND);
            ItemMeta im = inf.getItemMeta();
            im.displayName(Component.text("§bДлительность: " + (opt.isInfinite() ? "§aБесконечно" : "§e1 минута")));
            im.lore(List.of(Component.text("§7Нажмите, чтобы переключить (выход через /leave).")));
            inf.setItemMeta(im);
            inv.setItem(12, inf);
        }

        // Слот 14: Режим «Прогресс» (Уровни 1-5)
        ItemStack prog = new ItemStack(Material.EXPERIENCE_BOTTLE);
        ItemMeta prm = prog.getItemMeta();
        prm.displayName(Component.text("§6§lРежим «Прогресс» (Уровни)"));
        prm.lore(List.of(
                Component.text("§7Проходите уровни 1–5 по очереди,"),
                Component.text("§7сложность растёт с каждым уровнем!"),
                Component.text("§eНажмите, чтобы открыть уровни")
        ));
        prog.setItemMeta(prm);
        inv.setItem(14, prog);

        // Слот 16: НАЧАТЬ (обычная тренировка)
        ItemStack start = new ItemStack(Material.EMERALD_BLOCK);
        ItemMeta sm = start.getItemMeta();
        sm.displayName(Component.text("§a§l▶ НАЧАТЬ ТРЕНИРОВКУ"));
        sm.lore(List.of(Component.text("§7Режим: " + opt.getType().getDisplayName())));
        start.setItemMeta(sm);
        inv.setItem(16, start);

        // Слот 22: Назад
        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta bm = back.getItemMeta();
        bm.displayName(Component.text("§7← Назад к списку"));
        back.setItemMeta(bm);
        inv.setItem(22, back);

        player.openInventory(inv);
    }
}
