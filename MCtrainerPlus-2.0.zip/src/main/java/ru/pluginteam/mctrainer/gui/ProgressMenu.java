package ru.pluginteam.mctrainer.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.model.ProgressLevel;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.util.List;

public class ProgressMenu {
    public static final String TITLE = "§8Режим «Прогресс» — Уровни";

    public static void open(MCTrainerPlugin plugin, Player player, TrainerType type) {
        Inventory inv = Bukkit.createInventory(null, 27, Component.text(TITLE));
        int unlocked = plugin.getDataStore().getUnlockedLevel(player.getUniqueId(), type);

        int[] slots = {11, 12, 13, 14, 15};
        for (int lvl = 1; lvl <= ProgressLevel.MAX_LEVEL; lvl++) {
            boolean isUnlocked = lvl <= unlocked;
            boolean isDone = lvl < unlocked;

            Material mat = isDone ? Material.LIME_CONCRETE : (isUnlocked ? Material.YELLOW_CONCRETE : Material.RED_CONCRETE);
            ItemStack item = new ItemStack(mat, lvl);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text((isUnlocked ? "§eУровень " + lvl : "§cУровень " + lvl + " (Закрыт)")));
            meta.lore(List.of(
                    Component.text("§7Цель: §f" + ProgressLevel.getGoalDescription(type, lvl)),
                    Component.text("§7Сложность: " + ProgressLevel.getDifficultyForLevel(lvl).getDisplayName()),
                    Component.text(""),
                    Component.text(isDone ? "§a✔ Пройден (можно переиграть)" : (isUnlocked ? "§a▶ Нажмите, чтобы начать!" : "§cПройдите предыдущий уровень"))
            ));
            item.setItemMeta(meta);
            inv.setItem(slots[lvl - 1], item);
        }

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta bm = back.getItemMeta();
        bm.displayName(Component.text("§7← Назад"));
        back.setItemMeta(bm);
        inv.setItem(22, back);

        player.openInventory(inv);
    }
}
