package ru.pluginteam.mctrainer.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.util.List;

public class PracticeMenu {
    public static final String TITLE = "§8MCtrainer+ — Выбор тренировки";

    public static void open(MCTrainerPlugin plugin, Player player) {
        Inventory inv = Bukkit.createInventory(null, 45, Component.text(TITLE));
        NamespacedKey key = new NamespacedKey(plugin, "trainer_type");

        // Красивое центрированное расположение 9 режимов
        int[] slots = {10, 12, 14, 16, 20, 22, 24, 30, 32};
        TrainerType[] types = TrainerType.values();

        for (int i = 0; i < types.length && i < slots.length; i++) {
            TrainerType t = types[i];
            int unlocked = plugin.getDataStore().getUnlockedLevel(player.getUniqueId(), t);
            ItemStack item = new ItemStack(t.getIcon());
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text(t.getDisplayName()));
            meta.lore(List.of(
                    Component.text("§7" + t.getDescription()),
                    Component.text(""),
                    Component.text("§6Прогресс: §eУровень " + unlocked + "/5"),
                    Component.text("§aНажмите, чтобы настроить и начать")
            ));
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, t.name());
            item.setItemMeta(meta);
            inv.setItem(slots[i], item);
        }

        player.openInventory(inv);
    }
}
