package ru.pluginteam.mctrainer.model;

public class ProgressLevel {
    public static final int MAX_LEVEL = 5;

    public static Difficulty getDifficultyForLevel(int level) {
        return switch (level) {
            case 1 -> Difficulty.VERY_SLOW;
            case 2 -> Difficulty.SLOW;
            case 3 -> Difficulty.EASY;
            case 4 -> Difficulty.NORMAL;
            default -> Difficulty.HARD;
        };
    }

    public static int getClutchHeightForLevel(int level) {
        return switch (level) {
            case 1 -> 15;
            case 2 -> 25;
            case 3 -> 40;
            case 4 -> 55;
            default -> 75;
        };
    }

    public static int getGoalForLevel(TrainerType type, int level) {
        return switch (type) {
            case TRACKING -> 20 + level * 15; // очки точности (тиков на цели / 2)
            case FLICK -> 15 + level * 10;    // кол-во блоков за 60с
            case CLUTCH -> 5;                 // 5 из 6 на заданной высоте
            case STUNSLAM -> 3 + level * 3;   // успешных StunSlam за 60с
            case PEARL_AIM -> 5 + level * 4;  // попаданий жемчугом за 60с
            case ANCHOR -> 2 + level * 2;     // взорванных якорей за 15с
            case MACE, CRYSTAL, SWORD -> 10 + level * 8; // попаданий по боту
        };
    }

    public static String getGoalDescription(TrainerType type, int level) {
        int goal = getGoalForLevel(type, level);
        return switch (type) {
            case TRACKING -> "Набрать " + goal + " очков слежения";
            case FLICK -> "Попасть по " + goal + " блокам";
            case CLUTCH -> "5/6 ватердропов с высоты " + getClutchHeightForLevel(level) + " бл.";
            case STUNSLAM -> "Сделать " + goal + " StunSlam";
            case PEARL_AIM -> "Попасть жемчугом " + goal + " раз";
            case ANCHOR -> "Взорвать " + goal + " якорей за 15с";
            case MACE, CRYSTAL, SWORD -> "Нанести " + goal + " ударов по боту";
        };
    }
}
