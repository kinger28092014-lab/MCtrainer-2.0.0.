package ru.pluginteam.mctrainer.model;

import org.bukkit.Material;

public enum TrainerType {
    TRACKING("§bTracking", Material.ARMOR_STAND, "Слежение за стойкой (проходит сквозь игрока, плавные скорости)"),
    FLICK("§eFlick (Gridshot)", Material.TARGET, "Быстрые флики по блокам с красной обводкой без частиц"),
    CLUTCH("§3Clutch (Waterdrop)", Material.WATER_BUCKET, "Ватердроп: 5 из 6 падений, умная рекомендация высоты"),
    STUNSLAM("§6StunSlam", Material.MACE, "Сбитие щита топором + удар булавой за 1 прыжок"),
    PEARL_AIM("§5Pearl Aim", Material.ENDER_PEARL, "Попадание бесконечным жемчугом в телепортирующегося NPC"),
    ANCHOR("§cAnchor Trainer", Material.RESPAWN_ANCHOR, "15 секунд на взрыв якорей (таймер с первого якоря)"),
    MACE("§dMace Trainer", Material.WIND_CHARGE, "Тренировка булавы и зарядов ветра против бота"),
    CRYSTAL("§4Crystal Trainer", Material.END_CRYSTAL, "Кристаллы, обсидиан и якоря против бота"),
    SWORD("§aSword & Combo", Material.DIAMOND_SWORD, "Отработка комбо и стрейфа мечом против бота");

    private final String displayName;
    private final Material icon;
    private final String description;

    TrainerType(String displayName, Material icon, String description) {
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
    }

    public String getDisplayName() { return displayName; }
    public Material getIcon() { return icon; }
    public String getDescription() { return description; }
}
