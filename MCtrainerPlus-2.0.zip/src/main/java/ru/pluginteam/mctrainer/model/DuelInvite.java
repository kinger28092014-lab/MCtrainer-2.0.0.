package ru.pluginteam.mctrainer.model;

import java.util.UUID;

public class DuelInvite {
    private final UUID sender;
    private final UUID target;
    private final TrainerType type;
    private final long createdAt;

    public DuelInvite(UUID sender, UUID target, TrainerType type) {
        this.sender = sender;
        this.target = target;
        this.type = type;
        this.createdAt = System.currentTimeMillis();
    }

    public UUID getSender() { return sender; }
    public UUID getTarget() { return target; }
    public TrainerType getType() { return type; }
    public boolean isExpired() { return System.currentTimeMillis() - createdAt > 60_000L; }
}
