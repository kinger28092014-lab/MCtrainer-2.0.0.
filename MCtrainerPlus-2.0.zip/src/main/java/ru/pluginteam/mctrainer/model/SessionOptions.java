package ru.pluginteam.mctrainer.model;

public class SessionOptions {
    private TrainerType type;
    private Difficulty difficulty = Difficulty.SLOW;
    private boolean infinite = false;
    private int clutchHeight = 20;
    private int progressLevel = 0; // 0 = обычный режим, 1..5 = режим Прогресс

    public SessionOptions(TrainerType type) {
        this.type = type;
    }

    public TrainerType getType() { return type; }
    public void setType(TrainerType type) { this.type = type; }
    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }
    public boolean isInfinite() { return infinite; }
    public void setInfinite(boolean infinite) { this.infinite = infinite; }
    public int getClutchHeight() { return clutchHeight; }
    public void setClutchHeight(int clutchHeight) { this.clutchHeight = Math.max(8, Math.min(100, clutchHeight)); }
    public int getProgressLevel() { return progressLevel; }
    public void setProgressLevel(int progressLevel) { this.progressLevel = progressLevel; }
}
