package ru.pluginteam.mctrainer.model;

public enum Difficulty {
    VERY_SLOW("§aОчень медленно", 0.018, 0.012, 5, 10, 0.10),
    SLOW("§2Медленно", 0.032, 0.022, 7, 13, 0.14),
    EASY("§eЛёгкая", 0.050, 0.035, 9, 16, 0.18),
    NORMAL("§6Средняя", 0.080, 0.055, 12, 20, 0.25),
    HARD("§cСложная", 0.120, 0.085, 15, 25, 0.34),
    INSANE("§4Киберспорт", 0.165, 0.120, 18, 30, 0.42);

    private final String displayName;
    private final double trackingSpeed;
    private final double trackingVertical;
    private final int pearlMinDist;
    private final int pearlMaxDist;
    private final double botSpeed;

    Difficulty(String displayName, double trackingSpeed, double trackingVertical, int pearlMinDist, int pearlMaxDist, double botSpeed) {
        this.displayName = displayName;
        this.trackingSpeed = trackingSpeed;
        this.trackingVertical = trackingVertical;
        this.pearlMinDist = pearlMinDist;
        this.pearlMaxDist = pearlMaxDist;
        this.botSpeed = botSpeed;
    }

    public String getDisplayName() { return displayName; }
    public double getTrackingSpeed() { return trackingSpeed; }
    public double getTrackingVertical() { return trackingVertical; }
    public int getPearlMinDist() { return pearlMinDist; }
    public int getPearlMaxDist() { return pearlMaxDist; }
    public double getBotSpeed() { return botSpeed; }

    public Difficulty next() {
        Difficulty[] vals = values();
        return vals[(ordinal() + 1) % vals.length];
    }
}
